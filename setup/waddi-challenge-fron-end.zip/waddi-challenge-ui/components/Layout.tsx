import React from 'react';
import Head from 'next/head';
import { LayoutNavigationComponent } from './layout/Navigation';

import { LayoutFooterComponent } from './layout/Footer';
import { Fragment } from 'react';

export const Layout = (props: any) => {

    return <Fragment>
        <Head>
            <title>Waddi App</title>
        </Head>
        <LayoutNavigationComponent />
        <main className='main-container'>{props.children}</main>
        <LayoutFooterComponent />
    </Fragment>
}