import React from 'react';

export const LayoutFooterComponent = (props: any) => {

    return <footer className="footer-section" id="contacts">
        <div className="footer-section-container container">
            <div className="row">
                <div className="col- v-align my-2"></div>
                <div className="footer-section-copyright mt-2">
                    <p ><strong>© Copyright 2023</strong> Todos los derechos reservados</p>
                </div>
            </div>
        </div>
    </footer>
}
