import React from 'react';
import Link from 'next/link';
import { Fragment, useEffect, useState } from 'react';

import { useRouter } from 'next/router';
import { isAuthenticatedUser, closeModal } from '../../shared/utils';
import { ApiService } from '../../services/api.service';

import cookies from 'js-cookie';

export const LayoutNavigationComponent = (props: any) => {

  const router = useRouter();
  const [authenticated, setAuthenticated] = useState(false);
  const [user, setUser] = useState({
    role: '',
    id: 0,
    name: '',
    username: '',
  });

  const [loginForm, setLoginForm] = useState({
    username: '',
    password: ''
  });

  useEffect(() => {
    async function fetcher() {
      if (isAuthenticatedUser()) {
        // @ts-ignore
        const u = cookies.get(process.env.PROFILE) ? JSON.parse(cookies.get(process.env.PROFILE as string)) : '';
        setUser(u || '');
        setAuthenticated(true);
      } else {
        setAuthenticated(false);
      }
    }
    fetcher();
  }, []);

  async function handleLogin(e: any) {
    e.preventDefault();
    const data = await ApiService.post('/users/signing', loginForm);
    if (data) {
      // @ts-ignore
      cookies.set(process.env.TOKEN as string, data);
      const user = await ApiService.get('/users/get/one', true);
      if (user) {
        // @ts-ignore
        cookies.set(process.env.PROFILE as string, JSON.stringify(user));
        closeModal('#loginModal');
        user.role ? router.push('/account') : window.location.href = '/';
      }
    }
  }

  const handleLogOut = () => {
    cookies.remove(process.env.TOKEN as string);
    cookies.remove(process.env.PROFILE as string);
    setAuthenticated(false);
    router.push('/');
  }

  return <Fragment>

    {/* Login modal container */}
    <div className="modal fade" id="loginModal" tabIndex={-1} aria-labelledby="loginModalLabel" aria-hidden="true">
      <div className="modal-dialog">
        <div className="modal-content">
          <div className="modal-header login-modal-header">
            <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            <h5 className="modal-title" id="loginModalLabel">Signing</h5>
            <div className='row text-center'>
            </div>
          </div>
          <div className="modal-body">
            <div className="tab-pane fade show active" id="tab-signin" role="tabpanel" aria-labelledby="btn-signin">

              <form onSubmit={handleLogin} className="pt-2">

                <div className="form-group">
                  <label htmlFor="username">Username</label>
                  <input type="text"
                    className="form-control custom-input"
                    id="username"
                    aria-describedby="emailHelp"
                    value={loginForm.username}
                    onChange={e => setLoginForm({ ...loginForm, username: e.target.value })}
                    autoComplete="current-username"
                  />
                </div>

                <div className="form-group mt-3">
                  <label htmlFor="password">Password</label>
                  <input type="password"
                    className="form-control custom-input"
                    id="password"
                    value={loginForm.password}
                    onChange={e => setLoginForm({ ...loginForm, password: e.target.value })}
                    autoComplete="current-password"
                  />
                </div>

                <div className="form-group mt-3">
                  <button type="submit" className="nav-link btn btn-action w-100 btn-action-button">Accept</button>
                </div>

              </form>
            </div>

          </div>
        </div>
      </div>
    </div>

    <nav className='navbar fixed-top navbar-expand-lg'>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navigationNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon v-align">
          <i className="fas fa-bars text-white"></i>
        </span>
      </button>

      {/* Navbar logo */}
      <a className="navbar-brand" href="/">
      <img  src='https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/32/bf/5f/32bf5f63-f459-aa54-f5c9-e9b6f6d1d772/AppIcon-1x_U007emarketing-0-7-0-85-220.png/230x0w.webp' width={32} height={32} alt="post image" />
      </a>
      {/* Navbar links */}
      <div className="collapse navbar-collapse" id="navigationNav">

        <ul className='navbar-nav navbar-nav-scroll'>

          {
            !authenticated ?
              <li className='nav-item v-align'>
                <button type="button" className="nav-link btn btn-action btn-action-button" data-bs-toggle="modal" data-bs-target="#loginModal">
                  Signing
                </button>
              </li> : <></>
          }
          {
            authenticated && router.pathname !== '/account' ? <li className='nav-item'>
              <Link href='/account'>
                <a className='nav-link btn btn-action'>
                  Account
                </a>
              </Link>
            </li> : <></>
          }
          {
            authenticated && router.pathname === '/account' ? <div className='dropdown text-center'>
              <button className='btn btn-action-button btn-rounded' type="button" data-bs-toggle="dropdown" aria-expanded="false" ><i className="fas fa-ellipsis-h"></i></button>
              <ul className="dropdown-menu">
                <li><a className="dropdown-item" href="#" onClick={handleLogOut}>Log out</a></li>
              </ul>
            </div>
              :
              <>
              </>
          }
        </ul>
      </div>
    </nav >

  </Fragment >
};