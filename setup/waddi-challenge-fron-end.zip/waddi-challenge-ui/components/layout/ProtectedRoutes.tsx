import { useRouter } from 'next/router';
import { useEffect } from 'react';
import { isAuthenticatedUser } from '../../shared/utils';

const routes = ['/account'];

export const LayoutProtectedRoute = ({ children }) => {
    const router = useRouter();
    useEffect(() => {
        if (!isAuthenticatedUser() && routes.includes(router.pathname)) {
            window.location.href = '/';
        }
    })
    return children;
};