import React from 'react';
import { useTable, usePagination } from 'react-table';

export const Table = ({ columns, data, rowByPage }: { columns: any[], data: any[], rowByPage?: number }) => {

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        footerGroups,
        page,
        prepareRow,
        setPageSize,
        pageOptions,
        pageCount,
        gotoPage,
        nextPage,
        previousPage,
        canPreviousPage,
        canNextPage,
        state: { pageIndex, pageSize, autoResetPage },
    } = useTable(
        {
            columns,
            data,
            initialState: {
                pageSize: rowByPage || 15,
                pageIndex: 0
            },
            autoResetPage: false,
        },
        usePagination
    )
    return <>
        {
            data.length ?
                <div className='table-responsive'>

                    <table className='table' {...getTableProps()}>
                        <thead className='thead-dark'>
                            {headerGroups.map(headerGroup => (
                                <tr className='text-white' {...headerGroup.getHeaderGroupProps()}>
                                    {headerGroup.headers.map(column => (
                                        <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                                    ))}
                                </tr>
                            ))}
                        </thead>
                        <tbody {...getTableBodyProps()}>
                            {page.map(row => {
                                prepareRow(row)
                                return (
                                    <tr {...row.getRowProps()}>
                                        {row.cells.map(cell => {
                                            return <td {...cell.getCellProps()}>
                                                <small className='badge text-white bg-dark'>
                                                    {cell.render('Cell')}
                                                </small>
                                            </td>
                                        })}
                                    </tr>
                                )
                            })}
                        </tbody>
                    </table>

                    <div className="pagination">
                        <button onClick={() => gotoPage(0)} disabled={!canPreviousPage}>
                            {'<<'}
                        </button>{' '}
                        <button onClick={() => previousPage()} disabled={!canPreviousPage}>
                            {'<'}
                        </button>{' '}
                        <button onClick={() => nextPage()} disabled={!canNextPage}>
                            {'>'}
                        </button>{' '}
                        <button onClick={() => gotoPage(pageCount - 1)} disabled={!canNextPage}>
                            {'>>'}
                        </button>{' '}
                        <span>
                            Página{' '}
                            <strong>
                                {pageIndex + 1} of {pageOptions.length}
                            </strong>{' '}
                        </span>
                    </div>
                </div>
                : <div className='container no-results-container'>
                    <h1>
                        <i className="far fa-file"></i>
                    </h1>
                    <h6>No hay resultados</h6>
                </div>
        }
    </>
}