import React, { useEffect, useState, useMemo } from 'react'
import { ApiService } from '../../services';
import { dateToLocal } from '../../shared/utils/time.util';
import { LoaderComponent } from '../Loader';
import { Table } from '../Table';

export const LogsComponent = () => {

    const [logs, setLogs] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const fetcher = async () => {
            setIsLoading(true);
            await handleGetLogs();
            setIsLoading(false);
        }
        fetcher();
    }, []);

    const handleGetLogs = async () => {
        const result = await ApiService.get('/logs/get', true);
        if (result) { setLogs(result); };
    }

    const columns = useMemo(() =>
        [
            {
                Header: 'ID',
                Footer: 'ID',
                accessor: 'id',
                disableFilters: false,
                sticky: 'left',
            },
            {
                Header: 'Fecha',
                Footer: 'Fecha',
                accessor: 'createdAt',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => <>{dateToLocal(row.original.createdAt)}</>
            },
            {
                Header: 'Message',
                Footer: 'Message',
                accessor: 'message',
                disableFilters: false,
                sticky: 'left',
            },
        ], []);

    return <div className='account-tab-panel-container'>
        {
            isLoading ?
                <div className='loader-component-container'>
                    <LoaderComponent name='Procesando...' />
                </div> : <Table columns={columns} data={logs} />
        }
    </div>

}