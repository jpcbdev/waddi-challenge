import React from 'react';
import { useState, useEffect, useMemo } from 'react';
import { ApiService } from '../../services';

import { closeModal } from '../../shared/utils';
import { LoaderComponent } from '../Loader';

import { Table } from '../Table';

export const UsersComponent = () => {

    const [user, setUser] = useState({
        role: '',
        id: 0,
        name: '',
        username: '',
        password: '',
        permissions: [] as any[]
    });
    const [users, setUsers] = useState([] as any[]);
    const [update, setUpdate] = useState(false);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        const fetchData = async () => {
            setIsLoading(true);
            await getUsers();
            setIsLoading(false);
        }
        fetchData();
    }, []);

    async function getUsers() {
        const result = await ApiService.get('/users/get', true);
        if (result) setUsers(result.reverse());
    }

    async function handleDelete(id: number) {
        const result = await ApiService.delete('/users/delete/one', { id }, true, false);
        if (result) await getUsers();
    }

    async function handleCreate() {
        const result = await ApiService.post('/users/create', {
            name: user.name,
            username: user.username,
            role: user.role,
            password: user.password,
            permissions: user.permissions
        }, true, false);
        if (result) {
            await getUsers();
            closeModal('#editUserModal');
        };
    }

    async function handleUpdate() {
        const result = await ApiService.put('/users/update/one', {
            id: user.id,
            name: user.name,
            password: user.password,
            permissions: user.permissions,
        }, true);
        if (result) {
            closeModal('#editUserModal');
            await getUsers();
        };
    }

    function setUserToUpdate($in) {
        setUser($in)
    }

    const columns = useMemo(() =>
        [
            {
                Header: 'ID',
                Footer: 'ID',
                accessor: 'id',
                disableFilters: false,
                sticky: 'left',
            },
            {
                Header: 'Usuario',
                Footer: 'Usuario',
                accessor: 'username',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => (<span className='text-success m-0 p-0'>{row.original.username}</span>)
            },
            {
                Header: 'Tipo',
                Footer: 'Tipo',
                accessor: 'role',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => (<span className='text-white m-0 p-0'>{row.original?.role.toUpperCase()}</span>)
            },
            {
                Header: 'Acciones',
                Footer: 'Acciones',
                accessor: 'actions',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => (
                    <>
                        <button className={'action-button-rounded'}
                            data-bs-toggle="modal"
                            data-bs-target="#editUserModal"
                            onClick={() => { setUpdate(true); setUserToUpdate(row.original); }}>
                            <i className="fas fa-edit"></i>
                        </button>
                        <button className="action-button-rounded"
                            data-bs-toggle="modal" data-bs-target="#deleteUser"
                            onClick={() => setUser({ ...row.original, _id: row.original._id, username: row.original.username })}
                        >
                            <i className="fas fa-trash-alt"></i>
                        </button>
                        {row.original.active === false ? <span className='text-danger'> {" > Inactivo"} </span> : null}
                    </>
                )
            },
        ], []);

    return <div className="account-tab-panel-container">

        {/* Delete user modal */}
        <div className="modal fade" id="deleteUser" tabIndex={-1} aria-labelledby="deleteUserLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        <h5 className="modal-title" id="exampleModalLabel"></h5>
                    </div>
                    <div className="modal-body text-white">
                        ¿Realmente desea eliminar el usuario: {user.username}?
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-warning" onClick={() => handleDelete(user.id)} data-bs-dismiss="modal">Aceptar</button>
                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>

        {/* Edit user modal*/}
        <div className="modal fade" id="editUserModal" tabIndex={-1} aria-labelledby="editUserModalLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content text-dark">
                    <div className="modal-header">
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        <h5 className="modal-title" id="editUserModalLabel"> {!update ? 'Crear usuario' : 'Actualizar usuario'}</h5>
                    </div>
                    <div className="modal-body">
                        <form>
                            <div className="form-group">
                                <label htmlFor="userName">Nombre
                                    <small className="form-text text-danger">*</small>
                                </label>
                                <input type="text" className="form-control" id="userName" aria-describedby="emailHelp"
                                    value={user.name}
                                    onChange={e => setUser({ ...user, name: e.target.value })}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="userUsername">Usuario
                                    {
                                        !update ? <small className="form-text text-danger">*</small> : <></>
                                    }
                                </label>
                                <input type="text" className="form-control"
                                    disabled={update ? true : false}
                                    id="userUsername"
                                    value={user.username}
                                    onChange={e => setUser({ ...user, username: e.target.value })}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="userUsername">Contraseña
                                    {
                                        !update ? <small className="form-text text-danger">*</small> : <></>
                                    }
                                </label>
                                <input type="text" className="form-control"
                                    disabled={update ? true : false}
                                    id="userPassword"
                                    value={user.password}
                                    onChange={e => setUser({ ...user, password: e.target.value })}
                                />
                            </div>


                            <div className="form-group">
                                <label htmlFor="roleSelect">Tipo
                                    {
                                        !update ? <small className="form-text text-danger">*</small> : <></>
                                    }
                                </label>
                                <select
                                    className="form-control" id="roleSelect"
                                    disabled={update ? true : false}
                                    value={user.role}
                                    onChange={e =>
                                        setUser({ ...user, role: e.target.value })
                                    }>
                                    <option value="user">Usuario</option>
                                </select>
                            </div>

                            <div className="form-group">
                                <label htmlFor="permissionsSelect">Permisos
                                    {
                                        !update ? <small className="form-text text-danger">*</small> : <></>
                                    }
                                </label>
                                <select
                                    className="form-control" id="permissionsSelect"
                                    value={user.permissions[0]}
                                    onChange={e =>
                                        setUser({ ...user, permissions: [e.target.value] })
                                    }>
                                    <option value="update">Actualizar</option>
                                    <option value="read_write">Eliminar y crear</option>
                                </select>
                            </div>

                            <div className="form-group text-center mb-1">
                                <small className="form-text text-muted">(<strong className="text-danger">*</strong>) Campos requeridos</small>
                            </div>
                        </form>
                    </div>

                    <div className="modal-footer">
                        <button type="button"
                            className="btn btn-warning"
                            onClick={!update ? handleCreate : handleUpdate}
                        >Aceptar</button>
                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>

        {/* Create user trigger */}
        < div className="row" >
            <div className="col-12 text-end account-modal-trigger">
                <a className="text-warning m-2" data-bs-toggle="modal"
                    data-bs-target="#editUserModal" onClick={() => {
                        setUser({
                            id: 0,
                            name: '',
                            username: '',
                            role: 'user',
                            password: '',
                            permissions: ['update']
                        }); setUpdate(false);
                    }} >
                    <i className="fas fa-user-plus"></i>
                </a>
            </div>

        </div >

        {
            isLoading ?
                <div className='loader-component-container'>
                    < LoaderComponent name='Procesando...' />
                </div > : <Table columns={columns} data={users}></Table>
        }

    </div >
}
