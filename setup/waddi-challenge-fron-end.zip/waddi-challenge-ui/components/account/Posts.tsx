import React, { useEffect, useState, useMemo } from 'react'
import { ApiService } from '../../services';
import { closeModal } from '../../shared/utils';
import { dateToLocal } from '../../shared/utils/time.util';
import { LoaderComponent } from '../Loader';
import { Table } from '../Table';

export const PostComponents = () => {

    const [posts, setPosts] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [post, setPost] = useState({
        id: 0,
        title: '',
        content: '',
    });
    const [update, setUpdate] = useState(false);

    useEffect(() => {
        const fetcher = async () => {
            setIsLoading(true);
            await handleGetPosts();
            setIsLoading(false);
        }
        fetcher();
    }, []);

    const handleGetPosts = async () => {
        const result = await ApiService.get('/posts/get', false);
        if (result) { setPosts(result); };
    }

    async function handleCreate() {
        const result = await ApiService.post('/posts/create', {
            title: post.title,
            content: post.content,
        }, true, false);
        if (result) {
            await handleGetPosts();
            closeModal('#editPostModal');
        };
    }

    async function handleUpdate() {
        const result = await ApiService.put('/posts/update/one', {
            id: post.id,
            title: post.title,
            content: post.content,
        }, true);
        if (result) {
            closeModal('#editPostModal');
            await handleGetPosts();
        };
    }

    async function handleDelete(id: number) {
        const result = await ApiService.delete('/posts/delete/one', { id }, true, false);
        if (result) await handleGetPosts();
    }

    function setPostToUpdate(post) {
        setPost(post)
    }

    const columns = useMemo(() =>
        [
            {
                Header: 'ID',
                Footer: 'ID',
                accessor: 'id',
                disableFilters: false,
                sticky: 'left',
            },
            {
                Header: 'Fecha',
                Footer: 'Fecha',
                accessor: 'createdAt',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => <>{dateToLocal(row.original.createdAt)}</>
            },
            {
                Header: 'Título',
                Footer: 'Título',
                accessor: 'title',
                disableFilters: false,
                sticky: 'left',
            },
            {
                Header: 'User ID',
                Footer: 'User ID',
                accessor: 'UserId',
                disableFilters: false,
                sticky: 'left',
            },
            {
                Header: 'Acciones',
                Footer: 'Acciones',
                accessor: 'actions',
                disableFilters: false,
                sticky: 'left',
                Cell: ({ row }) => (
                    <>
                        <button className={'action-button-rounded'}
                            data-bs-toggle="modal"
                            data-bs-target="#editPostModal"
                            onClick={() => { setUpdate(true); setPostToUpdate(row.original); }}>
                            <i className="fas fa-edit"></i>
                        </button>
                        <button className="action-button-rounded"
                            data-bs-toggle="modal" data-bs-target="#deletePost"
                            onClick={() => setPost({ ...row.original, id: row.original.id })}
                        >
                            <i className="fas fa-trash-alt"></i>
                        </button>
                    </>
                )
            },

        ], []);

    return <div className='account-tab-panel-container'>

        {/* Edit post modal*/}
        <div className="modal fade" id="editPostModal" tabIndex={-1} aria-labelledby="editPostModalLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content text-dark">
                    <div className="modal-header">
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        <h5 className="modal-title" id="editPostModalLabel"> {!update ? 'Crear usuario' : 'Actualizar usuario'}</h5>
                    </div>
                    <div className="modal-body">
                        <form>
                            <div className="form-group">
                                <label htmlFor="title">Título
                                    <small className="form-text text-danger">*</small>
                                </label>
                                <input type="text" className="form-control" id="title" aria-describedby="emailHelp"
                                    value={post.title}
                                    onChange={e => setPost({ ...post, title: e.target.value })}
                                />
                            </div>

                            <div className="form-group">
                                <label htmlFor="content">Contenido
                                    <small className="form-text text-danger">*</small>
                                </label>
                                <textarea className="form-control" id="content" aria-describedby="emailHelp"
                                    value={post.content}
                                    onChange={e => setPost({ ...post, content: e.target.value })}
                                />
                            </div>

                            <div className="form-group text-center mb-1">
                                <small className="form-text text-muted">(<strong className="text-danger">*</strong>) Campos requeridos</small>
                            </div>
                        </form>
                    </div>

                    <div className="modal-footer">
                        <button type="button"
                            className="btn btn-warning"
                            onClick={!update ? handleCreate : handleUpdate}
                        >Aceptar</button>
                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>

        {/* Create user trigger */}
        < div className="row" >
            <div className="col-12 text-end account-modal-trigger">
                <a className="text-warning m-2" data-bs-toggle="modal"
                    data-bs-target="#editPostModal" onClick={() => {
                        setPost({
                            id: 0,
                            title: '',
                            content: '',
                        }); setUpdate(false);
                    }} >
                    <i className="fas fa-plus"></i>
                </a>
            </div>
        </div >

        {/* Delete user modal */}
        <div className="modal fade" id="deletePost" tabIndex={-1} aria-labelledby="deletePostLabel" aria-hidden="true">
            <div className="modal-dialog">
                <div className="modal-content">
                    <div className="modal-header">
                        <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                        <h5 className="modal-title" id="exampleModalLabel"></h5>
                    </div>
                    <div className="modal-body text-white">
                        ¿Realmente desea eliminar el post: {post.id}?
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-warning" onClick={() => handleDelete(post.id)} data-bs-dismiss="modal">Aceptar</button>
                        <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Cancelar</button>
                    </div>
                </div>
            </div>
        </div>


        {
            isLoading ?
                <div className='loader-component-container'>
                    <LoaderComponent name='Procesando...' />
                </div> : <Table columns={columns} data={posts} />
        }
    </div>

}