const env = process.env.NODE_ENV;

module.exports = {
    env: {
        PROFILE: env === 'development' ? 'aasdN2qwdjV0mnsH3T5' : 'bBqwd35asdasds1vEtuJL',
        TOKEN: env === 'development' ? '0YAqwd3k5rzasdslAP' : 'B61X2MW4Bqasdwd5kC',
        API_URL: env === 'development' ? 'http://0.0.0.0:3800' : 'http://0.0.0.0:3800',
    }
}