import moment from 'moment';
export function timeToLocal(time: string): string {
    const gmtDateTime = moment.utc(time, 'h:mm A')
    return gmtDateTime.local().format('h:mm A');
}

export function dateToLocal(date: string, short = false): string {

    let format = 'M/DD/YY, h:mm A'
    if (short) {
        format = 'M/DD/YY'
    }

    const gmtDateTime = moment(new Date(date), format)
    return gmtDateTime.local().format(format);

}