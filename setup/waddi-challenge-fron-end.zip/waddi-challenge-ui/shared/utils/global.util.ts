import cookies from 'js-cookie';

export function closeModal(id: string) {
    const truck_modal = document.querySelector(id);
    //@ts-ignore
    const modal = bootstrap.Modal.getInstance(truck_modal);
    if (modal) modal.hide();
}

export function isAuthenticatedUser(): any {
    return cookies.get(process.env.TOKEN as string) || null;
}

export function getCookieUser(): any {
    if (isAuthenticatedUser()) {
        // @ts-ignore
        return JSON.parse(cookies.get(process.env.PROFILE));
    }
}

export const isAdminComponent = (component: JSX.Element) => {
    const user = getCookieUser();
    if (user?.role === 'admin') return component;
    return null;
}
