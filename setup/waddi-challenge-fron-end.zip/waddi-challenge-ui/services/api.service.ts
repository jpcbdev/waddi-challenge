import cookies from 'js-cookie';
import { Notification } from '../shared/utils';

export class ApiService {

    private static url = process.env.API_URL;

    static async get(path: string, token?: boolean) {
        try {
            const query = await fetch(`${this.url}${path}`, {
                method: 'get', headers: {
                    'Authorization': token ? `Bearer ${this.setBearerToken()}` : '',
                },
            }).catch(() => { throw new Error('Error de conexión') });
            const response = await query.json();
            this.checkStatusCode(response);
            return response;
        } catch (error) {
            Notification.showError(error.message);
        }
    }

    static async getFile(path: string, token?: boolean) {
        try {
            const data = await fetch(`${this.url}${path}`,
                { method: 'get', headers: { 'Authorization': token ? `Bearer ${this.setBearerToken()}` : '', }, })
                .then(file => file.blob())
                .then(blob => URL.createObjectURL(blob))
            return data;
        } catch (error) {
            Notification.showError(error.message);
        }
    }

    static async post(path: string, body: object, token?: boolean, formData?: boolean): Promise<any> {
        try {
            const headers = { 'Authorization': token ? `Bearer ${this.setBearerToken()}` : '' };
            if (!formData) { headers['Accept'] = 'application/json'; headers['Content-Type'] = 'application/json'; }
            const query = await fetch(`${this.url}${path}`,
                {
                    method: 'post',
                    headers,
                    body: formData ? body : JSON.stringify(body) as any,
                }).catch((error) => { console.log(error); throw new Error('Error de conexión') });
            const response = await query.json();
            console.log(response)
            this.checkStatusCode(response);
            return response;
        } catch (error) {
            Notification.showError(error.message);
        }
    }

    static async put(path: string, body: object, token?: boolean, formData?: boolean): Promise<any> {
        try {
            const headers = { 'Authorization': token ? `Bearer ${this.setBearerToken()}` : '', };
            if (!formData) { headers['Accept'] = 'application/json'; headers['Content-Type'] = 'application/json'; }
            const query = await fetch(`${this.url}${path}`,
                {
                    method: 'put',
                    headers,
                    body: formData ? body : JSON.stringify(body) as any,
                }).catch(() => { throw new Error('Error de conexión') });
            const response = await query.json();
            this.checkStatusCode(response);
            return response;
        } catch (error) {
            Notification.showError(error.message);
        }
    }

    static async delete(path: string, body: object, token?: boolean, formData?: boolean): Promise<any> {
        try {
            const headers = { 'Authorization': token ? `Bearer ${this.setBearerToken()}` : '', };
            if (!formData) { headers['Accept'] = 'application/json'; headers['Content-Type'] = 'application/json'; }
            const query = await fetch(`${this.url}${path}`,
                {
                    method: 'delete',
                    headers,
                    body: formData ? body : JSON.stringify(body) as any,
                }).catch(() => { throw new Error('Error de conexión') });
            const response = await query.json();
            this.checkStatusCode(response);
            return response;
        } catch (error) {
            Notification.showError(error.message);
        }
    }

    static checkStatusCode(response: any) {
        if (typeof response.statusCode === 'number' && ![200, 201, 202, 203, 204].includes(response.statusCode)) {
            let message = '';
            message = Array.isArray(response.message) ? response.message[0] : response.message;
            message = message.replace('card.', '');
            if (response?.statusCode === 401) { this.logOutUser(); }
            throw new Error(message);
        };
    }

    private static setBearerToken(): string {
        const cookie = cookies.get(process.env.TOKEN as string) || '';
        const token = JSON.parse(cookie)?.token ?? '';
        return token;
    }

    private static logOutUser() {
        cookies.remove(process.env.TOKEN as string);
        cookies.remove(process.env.PROFILE as string);
        window.location.href = '/';
    }

}
