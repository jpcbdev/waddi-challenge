
import React from 'react';
import { Layout } from '../components/Layout';
import Head from 'next/head';

import { useEffect, useState } from 'react';
import { ApiService } from '../services';
import { closeModal } from '../shared/utils';

const Index = (props: any) => {

    const [posts, setPosts] = useState([]);
    const [post, setPost] = useState({
        id: 0,
        title: '',
        content: '',
        Reviews: [] as any[]
    });

    const [review, setReview] = useState({
        comment: '',
        stars: 0
    });

    useEffect(() => {
        const fetcher = async () => await handleGetPosts();
        fetcher();
    }, []);

    const handleGetPosts = async () => {
        const result = await ApiService.get('/posts/get', false);
        if (result) { setPosts(result); };
    }

    const handleCreateReview = async (postId: number) => {
        console.log(review)
        const result = await ApiService.post('/reviews/create', {
            postId,
            stars: review.stars,
            comment: review.comment
        });
        if (result) {
            await handleGetPosts();
            closeModal('#viewPost');
            setReview({
                comment: '',
                stars: 0
            })
        };
    }

    return <Layout>
        <Head>
            <title>Waddi App</title>
            <link rel='icon' href='/favicon.ico' />
        </Head>
        <main className='main-container-back-office'>

            {/* View post modal */}
            <div className="modal fade" id="viewPost" tabIndex={-1} aria-labelledby="viewPostLabel" aria-hidden="true">
                <div className="modal-dialog modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                            <h3 className="modal-title" id="exampleModalLabel">{post.title}</h3>
                        </div>
                        <div className="modal-body text-white">
                            {post.content}

                            <div className='mt-5'>
                                <h6>Reviews</h6>
                                {
                                    post?.Reviews?.map((review, i) => {
                                        return <p key={i}>{review.comment} - {review.stars} <i className="fas fa-star m-1 text-warning"></i></p>
                                    })
                                }
                            </div>

                            <div className='row bg-white text-dark m-2'>
                                <h4>Dejar comentario</h4>
                                <div className="col-s12">
                                    <textarea className='w-100'
                                        rows={10}
                                        id="reviewComment"
                                        value={review.comment}
                                        placeholder="Comentario"
                                        onChange={e =>
                                            setReview({ ...review, comment: e.target.value })
                                        }
                                    />
                                </div>

                                <div className="col-s12">
                                    <label htmlFor="starsSelect">Estrellas</label>
                                    <select
                                        className="form-control" id="starsSelect"
                                        value={review.stars}
                                        onChange={e =>
                                            setReview({ ...review, stars: Number.parseInt(e.target.value) })
                                        }>
                                        <option value="0">Seleccione las estrellas</option>
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                </div>
                                <button type="button" className="btn btn-warning" onClick={() => handleCreateReview(post.id)}>Crear review</button>

                            </div>

                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal">Salir</button>
                        </div>
                    </div>
                </div>
            </div>
            <div className='row'>
                {
                    posts.map((post: any) => {
                        return <div className='col-xs-12 col-sm-12 col-md-4 col-lg-4 p-2 text-center'>
                            <div className="card h-100 p-1 border-less ">
                                <div className='text-center'>
                                    <img src='https://is3-ssl.mzstatic.com/image/thumb/Purple126/v4/32/bf/5f/32bf5f63-f459-aa54-f5c9-e9b6f6d1d772/AppIcon-1x_U007emarketing-0-7-0-85-220.png/230x0w.webp' width={80} height={80} alt="post image" />
                                </div>
                                <div className="card-body">
                                    <h5 className="card-text document-title my-2">{post.title}</h5>
                                    <div className="card-footer card-text my-2">
                                        <a className='w-100 stretched-link' type='button'
                                            data-bs-toggle="modal"
                                            data-bs-target="#viewPost"
                                            onClick={() => { setPost(post) }}
                                        >Leer más</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    })
                }
            </div>
        </main>
    </Layout>
};

export default Index;
