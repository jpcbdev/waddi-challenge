import React from 'react';
import Head from 'next/head';
import '../styles/globals.css'

import Router from 'next/router';
import NProgress from 'nprogress';

import { LayoutProtectedRoute } from '../components/layout/ProtectedRoutes'

import Loader from 'react-loader-spinner';
import { useEffect, useState } from 'react';

import 'toastify-js/src/toastify.css';

NProgress.configure({ easing: 'ease', speed: 500 });
Router.events.on('routeChangeStart', (url) => {
    NProgress.start();
});

Router.events.on('routeChangeComplete', () => NProgress.done());
Router.events.on('routeChangeError', () => NProgress.done());

function MyApp({ Component, pageProps }) {

    const [loading, setLoading] = useState(true);

    useEffect(() => { setTimeout(() => { setLoading(false) }, 3000) }, []);

    return loading ? <div className='app-loader-container'>
        <div className='col-12 d-flex justify-content-center'>
            <Loader
                type={'Circles'}
                color={'#fff'}
                height={100}
                width={100}
            ></Loader>
        </div>
    </div>
        :
        <>
            <Head>
                <meta name='viewport' content='minimum-scale=1, initial-scale=1, width=device-width' />
            </Head>
            <section className='index-section'>
                <LayoutProtectedRoute>
                    <Component {...pageProps} />
                </LayoutProtectedRoute>
            </section>
        </>

}

export default MyApp