import React from 'react';
import Head from 'next/head';
import { Layout } from '../components/Layout';

import { useState, useEffect } from 'react';
import cookies from 'js-cookie';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';

import { UsersComponent } from '../components/account/Users';
import { ApiService } from '../services';
import { getCookieUser } from '../shared/utils';

import { PostComponents } from '../components/account/Posts';
import { LogsComponent } from '../components/account/Logs';

const Account = (props: any) => {

    const [role, setRole] = useState('');
    const [user, setUser] = useState({
        role: '',
        id: 0,
        name: '',
        username: '',
        permissions: []
    });

    const [authenticated, setAuthenticated] = useState(false);

    useEffect(() => {
        setRole(getCookieUser().role);
        // @ts-ignore
        if (cookies.get(process.env.TOKEN)) {
            setUser(getCookieUser());
            setAuthenticated(true);
            getUser();
        } else {
            setAuthenticated(false);
        }
    }, []);

    async function getUser() {
        const result = await ApiService.get('/users/get/one', true);
        if (result) {
            setUser(result)
        };
    }

    return <Layout>

        <Head>
            <title>Account</title>
            <meta name="robots" content="noindex,nofollow" />
        </Head>

        <section className='admin-container' >

            <Tabs >
                <div className='row'>
                    {/* Tab list section */}
                    <TabList className={'nav nav-tabs col-xs-12 col-sm-12 col-md-3 col-lg-3 col-xl-3 p-2'}>
                        {user?.role ? <Tab className="nav-link text-start" id="nav-posts-tab" aria-selected="true"><i className="fas fa-book-reader me-2"></i>Posts</Tab> : <></>}
                        {user?.role === 'admin' ? <Tab className="nav-link text-start" id="nav-users-tab" aria-selected="false"><i className="fas fa-users me-2"></i>Usuarios</Tab> : <></>}
                        {user?.role === 'admin' ? <Tab className="nav-link text-start" id="nav-logs-tab" aria-selected="false"><i className="fas fa-clipboard-list me-2"></i>Logs</Tab> : <></>}
                    </TabList>

                    {/* Tab panes section */}
                    <div className='col-xs-12 col-sm-12 col-md-9 col-lg-9 col-xl-9 p-3'>
                        <TabPanel>
                            <PostComponents />
                        </TabPanel>
                        <TabPanel>
                            <UsersComponent />
                        </TabPanel>
                        <TabPanel>
                            <LogsComponent />
                        </TabPanel>

                    </div>
                </div>
            </Tabs>
        </section>
    </Layout>

};

export default Account;

